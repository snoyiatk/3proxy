#define VERSION "3proxy-0.8.9"
#define BUILDDATE "170202011430"
